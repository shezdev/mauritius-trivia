'use strict';

module.exports = {
    /**
     * When editing your questions pay attention to your punctuation. Make sure you use question marks or periods.
     * Make sure the first answer is the correct one. Set at least ANSWER_COUNT answers, any extras will be shuffled in.
     */
    "QUESTIONS_EN_GB" : [
        {
            "What is the capital of Mauritius?": [
                "Port Louis",
                "Saint Denis",
                "Victoria",
                "Malé"
            ]
        },
        {
            "What colors are in the national flag of Mauritius?": [
                "Red, Blue, Yellow and Green",
                "Blue, White and Red",
                "Red, Green and White",
                "Green, White and Orange"
            ]
        },
        {
            "What is the name of the famous flightless bird, once endemic to Mauritius and subsequently driven to extinction?": [
                "Dodo",
                "Labrador Duck",
                "Male passenger Pigeon",
                "Laughing Owl"
            ]
        },
        {
            "Who did the Dutch name Mauritius in honor of, in the year 1598?": [
                "Prince Maurits Van Nassau",
                "Maurice, Count of Oldenburg",
                "Maurice of Carnoet",
                "Maurice of Inchaffray"
            ]
        },
        {
            "What year did Mauritius gain independence from the British?": [
                "1968",
                "1948",
                "1958",
                "1978"
            ]
        },
        {
            "Which circle of latitude does Mauritius lie closest to?": [
                "Tropic of Capricorn",
                "Equator",
                "Tropic of Cancer",
                "Arctic Circle"
            ]
        },
        {
            "What is the national flower of Mauritius?": [
                "Boucle d'Oreille, (Trochetia Boutoniana)",
                "The King Protea, (Protea cynaroides)",
                "The Pink Rose (Finifenmaa)",
                "Lily"
            ]
        },
        {
            "What is the name of the national anthem of Mauritius": [
                "Motherland",
                "Ry Tanindraza nay malala o, (Oh, Our Beloved Fatherland)",
                "Gaumee Salaam, (National Salute)",
                "La Marseillaise, (The Song of Marseille)"
            ]
        },
        {
            "What is the national animal of Mauritius": [
                "Dodo",
                "Zebu",
                "Yellowfin Tuna",
                "Striped Dolphin"
            ]
        },
        {
            "What is the English translation of the latin motto on the Mauritius coat of arms?": [
                "Star and Key of the Indian Ocean",
                "Paradise and Star of the Indian Ocean",
                "Star and Jewel of the Indian Ocean",
                "Stag and Star of the Indian Ocean"
            ]
        },
        {
            "Which is one of the best swimming beaches in Mauritius?": [
                "Pereybere",
                "Gris Gris",
                "Le Morne",
                "Port Louis"
            ]
        },
        {
            "Where in Mauritius would you find the famous 7 colored earth geological formation?": [
                "Chamarel, in the South West",
                "Mahebourg, in the South East",
                "Flic en Flac, in the West",
                "Grand Baie, in the North"
            ]
        },
        {
            "What is the name of the most well known volcano in Mauritius": [
                "Trou aux Cerfs",
                "Trou aux Biches",
                "Trou d'eau Douce",
                "Tamarin"
            ]
        },
        {
          "What is the status of the well known volcano in Mauritius": [
              "Dormant",
              "Active",
              "Extinct",
              "Inactive"
            ]
        },
        {
            "What is the name of the highest mountain in Mauritius?": [
                "Piton de la Petite Rivière Noire",
                "Pieter Both",
                "Le Pouce",
                "Cocotte"
            ]
        },
        {
            "Who was the first prime minister of Mauritius?": [
                "Sir Seewoosagur Ramgoolam",
                "Sir Anerood Jugnauth",
                "Dr. Navin Ramgoolam",
                "Paul Bérenger"
            ]
        },
        {
            "Where is the beautiful National Botanical Garden of Mauritius": [
                "Pamplemousses",
                "Flacq",
                "Rivière du rempart",
                "Moka"
            ]
        },
        {
            "Which member of the British Royal family visited Mauritius in 1956?": [
                "Princess Margaret",
                "Queen Elizabeth II",
                "King Georges VI",
                "Princess Alexandra"
            ]
        },
        {
            "What is the currency used in Mauritius?": [
                "Rupee",
                "Pound",
                "Euro",
                "Dollar"
            ]
        },
        {
            "What is the name of the famous Horse Racecourse in Mauritius?": [
                "Champ de Mars",
                "Champ de Sars",
                "Champ de Vars",
                "Champ de Hars"
            ]
        },
        {
            "Which iconic landmark is the Chamarel Waterfall equivalent in height to?": [
                "The Statue of Liberty",
                "Big Ben",
                "The Eiffel Tower",
                "The Grand Canyon"
            ]
        },
        {
            "What is the most widely spoken language and lingua franca of Mauritius?": [
                "Creole",
                "Italian",
                "Irish",
                "Malay"
            ]
        },
        {
            "What is the traditional dance and music of Mauritius?": [
                "Séga",
                "Khon",
                "Kilalaky",
                "Bandiyaa Jehun"
            ]
        },
        {
            "When did Mauritius win its first Olympic medal?": [
                "2008",
                "2004",
                "2012",
                "2016"
            ]
        }
    ]
};
